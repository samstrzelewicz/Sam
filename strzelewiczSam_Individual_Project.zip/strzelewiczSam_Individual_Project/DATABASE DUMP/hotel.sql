-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 07, 2020 at 06:23 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `ID` int(10) UNSIGNED NOT NULL,
  `pic` varchar(400) DEFAULT NULL,
  `title` varchar(140) NOT NULL,
  `author_ID` int(10) UNSIGNED DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT 0,
  `date_published` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`ID`, `pic`, `title`, `author_ID`, `content`, `date_created`, `status`, `date_published`) VALUES
(1, 'https://www.omnihotels.com/-/media/images/hotels/pvddtn/digex/hero/pvddtn-2880x1870.jpg', 'Motel 90', 2, 90, NULL, 0, NULL),
(2, 'http://ihg.scene7.com/is/image/ihg/holiday-inn-hotel-and-suites-oakland-2533422671-4x3', 'Red Roof OUT', 0, 1, NULL, 0, NULL),
(4, 'https://cache.marriott.com/marriottassets/marriott/HNLWI/hnlwi-cochere-1995-hor-wide.jpg?interpolation=progressive-bilinear&downsize=1440px:*', 'Hilton', 0, 1, NULL, -1, NULL),
(5, 'https://cache.marriott.com/marriottassets/marriott/BOMSA/bomsa-exterior-0023-hor-feat.jpg?output-quality=70&interpolation=progressive-bilinear&downsize=1180px:*', 'Mile High Hotel', 0, 2, NULL, 0, NULL),
(11, 'https://pix10.agoda.net/hotelImages/124/1246280/1246280_16061017110043391702.jpg?s=1024x768', 'Motel 7', NULL, 10, NULL, 0, NULL),
(12, 'https://ihg.scene7.com/is/image/ihg/avid-hotels-tulsa-5868381575-4x3', 'Hotel 100', NULL, 10000, NULL, -1, NULL),
(13, 'https://www.ahstatic.com/photos/9399_ho_00_p_1024x768.jpg', 'Golf & Resort', 3, 10, NULL, 0, NULL),
(14, 'https://q-cf.bstatic.com/images/hotel/max1024x768/681/68184730.jpg', 'Random Hotel', NULL, 10, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts_users_likes`
--

CREATE TABLE `posts_users_likes` (
  `post_ID` int(10) UNSIGNED NOT NULL,
  `user_ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts_users_likes`
--

INSERT INTO `posts_users_likes` (`post_ID`, `user_ID`) VALUES
(4, 2),
(11, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(10) UNSIGNED NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `date_registered` datetime DEFAULT NULL,
  `date_deleted` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `email`, `password`, `role`, `first_name`, `last_name`, `status`, `date_registered`, `date_deleted`) VALUES
(1, 'sam@gmail.com', '', 0, 'Sam', 'Strzelewicz', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'bob@gmail.com', '$2y$10$Dhb0yin3.wXtVAJPuuTXnO/YrHCH8W8tzbd5OSO.x1c7kgzOa.UYi', 0, 'Bob', 'Bob', 0, '2020-04-19 11:03:51', NULL),
(3, 'test@gmail.com', '$2y$10$mWJczCwGN.L1oc91KT2KqOGd6qPIMETrnjeaJDMFIYycCJ04CoQAG', 1, 'Test', 'User', 0, NULL, NULL),
(4, 'random@gmail.com', '$2y$10$9520bO.sFZHj7r0ZLDDQK.ofW2D5z8u2zjo8wGUeC8i01P1qb4eOe', 0, 'Random', 'User', 0, '2020-04-29 03:03:11', NULL),
(5, 'man@gmail.com', '$2y$10$xzX6U4Kr4ghO9wr0urODRujZU6wxjNk4hM11ochrqpLMPlV8MrC46', 0, 'test', 'man', 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `posts_users_likes`
--
ALTER TABLE `posts_users_likes`
  ADD PRIMARY KEY (`post_ID`,`user_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
