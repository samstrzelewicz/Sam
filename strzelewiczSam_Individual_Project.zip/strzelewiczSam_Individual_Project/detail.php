<?php
require_once('settings.php');
require_once('MySQLDB.php');
require_once('Post2.php');

$post=new Post2(null,$_GET['id']);

require_once('template.php');
Template::showHeader($post->title);
$post->showDetail();
?>
<a href = "index.php" >Go Back</a>
<?php

Template::showFooter();