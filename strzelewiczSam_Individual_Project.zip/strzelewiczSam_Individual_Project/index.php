<?php
require_once('template.php');
require_once('settings.php');
require_once('auth/Auth.php');
require_once('MySQLDB.php');
require_once('Post2.php');

Template::showHeader('Hotel Viewing');
?>
<p>Hotel's Available:</p>
<?php

$pdo=MySQLDB::connect();

$posts=$pdo->query('SELECT posts.ID,posts.title,posts.pic,posts.status,posts.content,posts.author_ID,users.first_name,users.last_name FROM posts LEFT JOIN users ON users.ID=posts.author_ID');

while($post=$posts->fetch()){
	$p=new Post2($post);
	$p->showPreview();
}
Template::showFooter();