<?php
require_once('../settings.php');
require_once('../auth/Auth.php');
if(!Auth::is_logged()) header('location: ../auth/signin.php');
require_once('../Post2.php');
$post=new Post();
$pdo=MySQLDB::connect();
$query=$pdo->prepare('SELECT * FROM posts WHERE ID=?');
$query->execute([$_GET['id']]);
if($query->rowCount()==0)header('location:index.php');
$post=$query->fetch();
if($post->author_ID!=$_SESSION['user/ID']) header('location: detail.php?id='.$_GET['id']);
$post->delete($_GET['id']);
header('location:index.php');