<?php
require_once('../settings.php');
require_once('../auth/Auth.php');
if(!Auth::is_logged()) header('location: ../auth/signin.php');
$message='';
$alert_type='';
if(count($_POST)>0){
	require_once('../Post2.php');
	$post=new Post2();
	$error=$post->create($_POST);
	if(isset($error{0})){
		$message=$error;
		$alert_type='danger';
	}
	else{
		$message='The post has been added';
		$alert_type='success';
	}
}
require_once('../template.php');
Template::showHeader('Create a new hotel');
if(count($_POST)>0) echo '<div class="alert alert-'.$alert_type.'" role="alert">'.$message.'</div>';
	?>
	<form method="POST">
<div class="form-group">
	<label for="exampleInputEmail1">Picture Link</label>
	<textarea class="form-control" name="pic" ></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Hotel Name</label>
    <input type="text" class="form-control" name="title" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
	<label for="exampleInputEmail1">Rating</label>
	<textarea class="form-control" name="content" ></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Create new post</button>
</form>
<?php

Template::showFooter();