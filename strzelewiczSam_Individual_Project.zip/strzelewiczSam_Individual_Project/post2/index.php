<?php
require_once('../settings.php');
require_once('../template.php');

require_once('../MySQLDB.php');
require_once('../Post2.php');

Template::showHeader('Welcome');
?>
<p>Welcome to hotel booking</p>
<?php

$pdo=MySQLDB::connect();
$posts=$pdo->query('SELECT * FROM posts');
while($post=$posts->fetch()){
	$p=new Post2($post);
	$p->showPreview();
}
Template::showFooter();