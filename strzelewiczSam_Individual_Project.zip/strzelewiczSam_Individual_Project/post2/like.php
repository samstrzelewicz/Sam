<?php
require_once('../settings.php');
require_once('../Post2.php');
$post=new Post2();
$post->like($_GET['id']);
echo 'Like changed';