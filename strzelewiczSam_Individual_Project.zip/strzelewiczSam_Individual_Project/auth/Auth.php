<?php
require_once(APP_ROOT.'/MySQLDB.php');

class Auth{
	static function signup($data,$success_URL){
		if(count($data)>0){
			if(!isset($data['email']{0}) || !isset($data['password']{0})) return 'You must enter e-mail and password';
			if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) return 'Please enter a valid email address';
			$data['email']=strtolower($data['email']);
						$data['password']=trim($data['password']);
			if(strlen($data['password'])<8) return 'Please, enter a password that is at least 8 characters long.';
			
			$pdo=MySQLDB::connect();
			$query=$pdo->prepare('SELECT ID FROM users WHERE email=?');
			$query->execute([$data['email']]);
			if($query->rowCount()>0) return 'The email you entered is already associated with an account.';


			$data['password']=password_hash($data['password'], PASSWORD_DEFAULT);
			if(!isset($data['first_name']{0})) $data['first_name']='';
			if(!isset($data['last_name']{0})) $data['last_name']='';
			

			$query=$pdo->prepare('INSERT INTO users(email,password,first_name,last_name,date_registered) VALUES(?,?,?,?,?)');
			$query->execute([$data['email'],$data['password'],$data['first_name'],$data['last_name'],date('Y-m-d h:i:s')]);
			header('location: '.$success_URL);
		}
	}

	static function signin($data,$success_URL){
		if(count($data)>0){
			if(!isset($data['email']{0}) || !isset($data['password']{0})) return 'You must enter e-mail and password';
			if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) return 'Please enter a valid email address';
			$data['email']=strtolower($data['email']);
			
			$data['password']=trim($data['password']);
			if(strlen($data['password'])<8) return 'Please, enter a password that is at least 8 characters long.';
			
			$pdo=MySQLDB::connect();
			$query=$pdo->prepare('SELECT ID,password FROM users WHERE email=?');
			$query->execute([$data['email']]);
			if($query->rowCount()==0) return 'The e-mail you entered is not associated with any account';
			$user=$query->fetch();
			
			if(!password_verify($data['password'],$user['password'])) return 'The password you entered is not correct';
			$_SESSION['user/ID']=$user['ID'];
			header('location:'.$success_URL);
		}
	}


	static function signout($destination_URL){
		$_SESSION=[];
		session_destroy();
		header('location:'.$destination_URL);
	}

	static function is_logged($user_key='user/ID'){
		if(isset($_SESSION[$user_key])){
			if(is_numeric($_SESSION[$user_key])) return true;
			elseif(isset($_SESSION[$user_key]{0})) return true;
		}
		return false;
	}
}