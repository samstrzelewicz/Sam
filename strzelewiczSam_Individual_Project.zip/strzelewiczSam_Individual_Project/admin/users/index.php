<?php

require_once('../../settings.php');
require_once(APP_ROOT.'/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('../../template.php');
require_once('../../MySQLDB.php');

Template::showHeader('Manage users');

$pdo=MySQLDB::connect();
$rows=$pdo->query('SELECT * FROM users');
?>
<a class="btn btn-primary" href="admin/users/create.php">Create new user</a>
<?php

require_once('../../User.php');
echo '<table class="table">';
$counter=0;
while($row=$rows->fetch()){
	$user=new User($row['first_name'],$row['last_name'],$row['email'],$row['password']);
	echo $user->showPreview($row['ID']);
	$counter++;
}
echo '</table>';
Template::showFooter();