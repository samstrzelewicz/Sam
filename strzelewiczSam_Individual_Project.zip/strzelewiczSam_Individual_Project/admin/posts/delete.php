<?php
require_once('../../settings.php');
require_once(APP_ROOT.'/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('../../Post2.php');
$post=new Post2();
$post->delete($_GET['id']);
header('location:index.php');