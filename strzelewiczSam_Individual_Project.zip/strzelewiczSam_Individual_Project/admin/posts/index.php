<?php
require_once('../../settings.php');
require_once(APP_ROOT.'/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('../../MySQLDB.php');
require_once('../../template.php');

Template::showHeader('Manage posts');

?>
<a class="btn btn-primary" href="post2/create.php">Create new post</a>
<?php
require_once('../../Post2.php');
$pdo=MySQLDB::connect();
$rows=$pdo->query('SELECT * FROM posts');
echo '<table class="table">';
$counter=0;
while($row=$rows->fetch()){
	$post=new Post2($row);
	$post->showTableRow();
}
echo '</table>';
Template::showFooter();