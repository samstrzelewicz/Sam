<?php
require_once('../settings.php');
require_once('../auth/Auth.php');
if(!Auth::is_logged()) header('location: ../index.php');
require_once('../admin/Admin.php');
Admin::isAdmin('../index.php');

require_once('../template.php');

Template::showHeader('Welcome to the admin section');
?>
<p><a href="admin/users">Manage users</a></p>
<p><a href="admin/posts">Manage posts</a></p>
<?php

Template::showFooter();