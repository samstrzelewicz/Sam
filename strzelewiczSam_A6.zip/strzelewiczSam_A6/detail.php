<?php
//require_once('data.php');
//$beatles=file_get_contents('data.json');
//$hotels=json_decode($beatles,true);

include('functions.php');
$hotels=jsonToArray('data.json');

if(!isset($_GET['id'])){
	echo 'Please enter the id of a hotel or visit the <a href="index.php">index page</a>.';
	die();
}
if($_GET['id']<0 || $_GET['id']>count($hotels)-1){
	echo 'Please enter the id of a hotel or visit the <a href="index.php">index page</a>.';
	die();
}

$title=$hotels[$_GET['id']]['name'];
require('header.php');
?>
		<h1><?= $hotels[$_GET['id']]['name'] ?></h1>
		<p><?= $hotels[$_GET['id']]['price'] ?></p>
		<img src="<?= $hotels[$_GET['id']]['picture'] ?>" width="500" />
		<p><?= $hotels[$_GET['id']]['desc'] ?></p>
<?php
require('footer.php');