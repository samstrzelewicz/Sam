<?php

class User{
	public $email;
	public $password;
	
	public function __construct($email=null,$password=null){
		$this->email=$email;
		$this->password=$password;
	}
	public function create($data){
		if(!isset($data['email']{0}) || !isset($data['password']{0})) return 'Some fields are missing';
		if(!filter_var($data['email'],FILTER_VALIDATE_EMAIL)) return 'The email address is not valid';

		require_once('lib_csv.php');
		$users=readCSV('database.csv');
		$h = fopen('database.csv','r');
		while(!feof($h)){
			$line=fgets($h);
			if(strstr($line,$_POST['email'])){
				return 'email already registered';
			}
		}
		$data['password']=password_hash($data['password'],PASSWORD_DEFAULT);

		writeCSV('database.csv',$data);
		return 'Welcome';
	}
}