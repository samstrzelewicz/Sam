<?php
/*
Author: Nicholas Caporusso
Description: Uncomment the following lines and load the page for testing the features of the library
*/

// WRITE
//writeCSV('beatles.csv',[['firstname'=>'John','lastname'=>'Lennon'],['firstname'=>'Paul','lastname'=>'McCartney']],'w'); // write a recordset to a CSV file
//writeCSV('beatles.csv',['firstname'=>'George','lastname'=>'Harrison'],'a'); // append a record to a CSV file
//writeCSV('beatles.csv',[['firstname'=>'George','lastname'=>'Harrison'],['firstname'=>'Ringo','lastname'=>'Starr']],'a'); // append a recordset to a CSV file
//writeCSV('beatles.csv.php',[['firstname'=>'John','lastname'=>'Lennon'],['firstname'=>'Paul','lastname'=>'McCartney']],'w'); // write a recordset to a "secure" CSV file

// READ
//echo '<pre>';print_r(readCSV('beatles.csv')); // read a recordset from a CSV file
//echo '<pre>';print_r(readCSV('beatles.csv',1)); // read one record from a CSV file
//echo '<pre>';print_r(readCSV('beatles.csv',2,2)); // read the first 3 records from a CSV file
//echo '<pre>';print_r(readCSV('beatles.csv.php',1,1,';',true)); // read a recordset from a CSV file using columns

// MODIFY
//modifyCSV('beatles.csv',0,['firstname'=>'John','lastname'=>'Lennon','birthdate'=>'1940-10-09']); // modify the first record in a CSV file

// DELETE
//deleteCSV('beatles.csv'); // delete a CSV file
//deleteCSV('beatles.csv',0); // delete the first record from a CSV file
//deleteCSV('beatles.csv',[0,1]); // delete the first and the second records from a CSV file

// FIND
//echo '<pre>';print_r(findCSV('beatles.csv.php','John'));//find all records that exactly match one field
//echo '<pre>';print_r(findCSV('beatles.csv.php','John',1));//find the first record that exactly matches one field
//echo '<pre>';print_r(findCSV('beatles.csv.php',[1=>'John'])); //find all the records where the second column exactly matches a value
//echo '<pre>';print_r(findCSV('beatles.csv.php',[1=>'John'],1)); //find the first record where the second column exactly matches a value
//echo '<pre>';print_r(findCSV('beatles.csv.php','John',null,false));//find all records that contains one field
//echo '<pre>';print_r(findCSV('beatles.csv.php','John',1,false));//find the first record that contains one field
//echo '<pre>';print_r(findCSV('beatles.csv.php',[1=>'John'],null,false)); //find all the records where the second column contains a value
//echo '<pre>';print_r(findCSV('beatles.csv.php',[1=>'John'],1,false)); //find the first record where the second column contains a value
//echo '<pre>';print_r(findCSV('beatles.csv.php',['last'=>'Lennon'],1,false,';',true)); //find the first record where the second column contains a value

//
//TO-DO:
// add column support in write / modify
// add support for column reordering
// convert to class

function writeCSV($file,$data,$mode=null,$delimiter=';'){
	if(!isset($data)) return false;
	if(is_array($data)){
		if(isset($data[0]) && is_array($data[0])){
			for($i=0;$i<count($data);$i++) $data[$i]=implode($delimiter,$data[$i]);
			$data=implode("\n",$data);
		}else $data=implode($delimiter,$data);
	}
	$mode=isset($mode{0}) ? ($mode=='w' || $mode=='w+' ? 'w+' : 'a+') : (file_exists($file) ? 'a+' : 'w+');
	$h=fopen($file,$mode);
	if(!flock($h,LOCK_EX|LOCK_NB)) return false;
	if($mode=='w+' && strtolower(PATHINFO($file)['extension'])=='php') fwrite($h,'<?php die(); ?>'."\n");
	fwrite($h,$data."\n");
	fclose($h);
	return true;
}

function readCSV($file,$index=null,$limit=1,$delimiter=';',$columns=false){
	if(!file_exists($file)) return [];
	$handle=fopen($file,'r');
	$data=[];
	$count=0;
	if(strtolower(PATHINFO($file)['extension'])=='php') fgets($handle);
	if($columns) $columns=explode($delimiter,preg_replace('/\n$/','',fgets($handle)));
	while(!feof($handle)){
		$line=preg_replace('/\n$/','',fgets($handle));
		$line=strlen($line) > 0 ? explode($delimiter,$line) : '';
		if(is_array($line)){
			if(isset($index)){
				if($count>=$index) $data[]=is_array($columns) ? array_combine($columns,$line) : $line;
				if(isset($limit) && $count>=$index+$limit-1) break;
			}else $data[]=is_array($columns) ? array_combine($columns,$line) : $line;
		}
		$count++;
	}
	fclose($handle);
	if(count($data)==0) return [];
	if(isset($index)) if($limit==1) return $data[0];
	if(!is_array($data[count($data)-1])) unset($data[count($data)-1]);
	return $data;
}

function findCSV($file,$needle,$limit=null,$strict=true,$delimiter=';',$columns=false){
	if(!file_exists($file)) return [];
	$handle=fopen($file,'r');
	$data=[];
	$count=0;
	if(strtolower(PATHINFO($file)['extension'])=='php') fgets($handle);
	if($columns) $columns=explode($delimiter,preg_replace('/\n$/','',fgets($handle)));
	while(!feof($handle)){
		$line=preg_replace('/\n$/','',fgets($handle));
		$line=strlen($line) > 0 ? explode($delimiter,$line) : '';
		if(is_array($line)){
			if(is_array($columns)) $line=array_combine($columns,$line);
			if(is_array($needle)){
				if(isset($line[array_keys($needle)[0]])){
					if($strict && $line[array_keys($needle)[0]]==array_values($needle)[0]) $data[$count]=$line;
					elseif(!$strict && strstr($line[array_keys($needle)[0]],array_values($needle)[0])) $data[$count]=$line;
				}
			}else{
				foreach($line as $column){
					if($strict && $column==$needle) $data[$count]=$line;
					elseif(!$strict && strstr($column,$needle)) $data[$count]=$line;
				}
			}
			if(isset($limit) && count($data)==$limit) break;
		}
		$count++;
	}
	fclose($handle);
	if(count($data)==0) return [];
	return $data;
	
}

function modifyCSV($file,$index,$data,$delimiter=';'){
	if(!file_exists($file) || !isset($data) || !isset($index)) return false;
	$array=readCSV($file);
	if(!is_array($array) || !isset($array[$index])) return false;
	$array[$index]=$data;
	writeCSV($file,$array,'w',$delimiter);
	return true;	
}

function deleteCSV($file,$index=null,$delimiter=';'){
	if(!file_exists($file)) return false;
	if(!isset($index)){
		unlink($file);
		return true;
	}
	$array=readCSV($file);
	if(!is_array($array)) return false;
	if(is_array($index)){
		for($i=0;$i<count($index);$i++) $array[$index[$i]]=[];
	}else $array[$index]=[];
	writeCSV($file,$array,'w',$delimiter);
	return true;
}