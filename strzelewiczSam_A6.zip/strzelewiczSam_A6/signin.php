<?php
if(count($_POST)>0){
	if(isset($error{0})){
		$message=$error;
		$alert_type='danger';
	}
	else{
		$message='The user has been added';
		$alert_type='success';
	}
}
if(count($_POST)>0) echo '<div class="alert alert-'.$alert_type.'" role="alert">'.$message.'</div>';
?>

<form action="signin.php" method="POST">
E-mail
<input type="email" name="email" required/> <br />
Password
<input type="password" name="password" required minlength="8" /> <br />

<button type="submit">Sign In</button>

</form>

