<?php
//require_once('data.php');
//$beatles=file_get_contents('data.json');
//$members=json_decode($beatles,true);

include('functions.php');
$hotels=jsonToArray('data.json');

$title='Hotel Booking';
require('header.php');
printHeader($title);
?>
    <h1>Hotel Booking</h1>
	<?php
	for($i=0;$i<count($hotels);$i++){
		showItem($i,$hotels[$i]['name'],$hotels[$i]['picture']);
		echo '<hr>';
	}
require('footer.php');

echo 'Sign up here: <a href="signup.php">Sign up</a>';

echo '<br>';

echo 'Log in here: <a href="signin.php">Log in</a>';
