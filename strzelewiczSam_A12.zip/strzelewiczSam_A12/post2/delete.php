<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/auth/Auth.php');
if(!Auth::is_logged()) header('location: ../auth/signin.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/Post2.php');
$post=new Post();
//connect to the database
$pdo=MySQLDB::connect();
//select post by id
$query=$pdo->prepare('SELECT * FROM posts WHERE ID=?');
$query->execute([$_GET['id']]);
// check if the post exists
if($query->rowCount()==0)header('location:index.php');
$post=$query->fetch();
// check post author
if($post->author_ID!=$_SESSION['user/ID']) header('location: detail.php?id='.$_GET['id']);
//delete the post
$post->delete($_GET['id']);
header('location:index.php');