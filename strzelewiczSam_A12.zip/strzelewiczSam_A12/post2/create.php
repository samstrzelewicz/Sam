<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/auth/Auth.php');
if(!Auth::is_logged()) header('location: ../auth/signin.php');
$message='';
$alert_type='';
if(count($_POST)>0){
	require_once('/opt/lampp/htdocs/strzelewiczSam_A12/Post2.php');
	$post=new Post();
	$error=$post->create($_POST);
	if(isset($error{0})){
		$message=$error;
		$alert_type='danger';
	}
	else{
		$message='The post has been added';
		$alert_type='success';
	}
}
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/template.php');
Template::showHeader('Create a new post');
if(count($_POST)>0) echo '<div class="alert alert-'.$alert_type.'" role="alert">'.$message.'</div>';
	?>
	<form method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">Title</label>
    <input type="text" class="form-control" name="title" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
	<label for="exampleInputEmail1">Content</label>
	<textarea class="form-control" name="content" ></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Create new post</button>
</form>
<?php

Template::showFooter();