<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/MySQLDB.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/Post2.php');

$post=new Post2(null,$_GET['id']);

require_once('/opt/lampp/htdocs/strzelewiczSam_A12/template.php');
Template::showHeader($post->title);
$post->showDetail();
?>
<a class="btn btn-outline-secondary" href="index.php">Go back</a>
<?php

Template::showFooter();