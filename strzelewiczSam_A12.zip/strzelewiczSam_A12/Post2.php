<?php
require_once('settings.php');
require_once('MySQLDB.php');
require_once('User.php');

class Post2{
	public $ID;
	public $pic;
	public $title;
	private $author_ID;
	public $content;
	private $date_created;
	private $status;
	private $date_published;
	private $author;
	public $likes;
	
	function __construct($data=null,$id=null){
		if($data==null && $id==null) return;
		if(isset($id)){

			$pdo=MySQLDB::connect();
			$query=$pdo->prepare('SELECT * FROM posts WHERE ID=?');
			$query->execute([$id]);
			$data=$query->fetch();
		}
		$this->ID=$data['ID'];
		$this->pic=$data['pic'];
		$this->title=$data['title'];
		$this->content=$data['content'];
		$this->author_ID=$data['author_ID'];
		$this->status=$data['status'];
		$this->likes=$data['likes'];
		$this->author=new User();
		if(isset($data['first_name'])) $this->author->first_name=$data['first_name'];
		if(isset($data['last_name'])) $this->author->last_name=$data['first_name'];
	}
	
	public function create($data){

		if(!isset($data['title']{0})) return 'The title is missing';
		$pdo=MySQLDB::connect();

		$query=$pdo->prepare('INSERT INTO posts (title,content) VALUES (?,?)');
		$query->execute([$data['title'],$data['content']]);
	}
	
	public function update($id,$data){

		if(!isset($data['title']{0})) return 'The title is missing';

		$pdo=MySQLDB::connect();

		$query=$pdo->prepare('UPDATE posts SET title=?,content=? WHERE ID=?');
		$query->execute([$data['title'],$data['content'],$id]);
	}
	
	public function delete($id){

		$pdo=MySQLDB::connect();

		$query=$pdo->prepare('UPDATE posts SET status=-1 WHERE ID=?');
		$query->execute([$id]);
	}
	
	public function showDetail(){
		echo '<td>'.'<img src="'.$this->pic.'" width="500" />'.'</td>';
		echo '<p>'.$this->content." star rating".'</p>';
	}
	
	public function showPreview(){
		echo '<h3>'.$this->title.' ('.$this->author->first_name.')</h3>';
		echo '<td>'.'<img src="'.$this->pic.'" width="100" />'.'</td>';
		echo '<p>'.$this->content." star rating ".'</p>';
		echo '<p>'.$this->likes." likes ".'</p>';
		echo '<a href="post2/detail.php?id='.$this->ID.'">Click for details</a> <br>';
		if(isset($_SESSION['user/ID']) && $this->author_ID==$_SESSION['user/ID']) echo '<a href="admin/posts/edit.php?id='.$this->ID.'">Edit this post</a>';
		echo '<hr>';
	}

	public function showLike(){
		?>
		<form action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
		<input type = "submit" value = "Like"/>
		</form>
		<?
	}
	
	public function showTableRow(){
		echo '<tr>';
		echo '<td>'.$this->ID.'</td>';
		echo '<td>'.'<img src="'.$this->pic.'" width="100" />'.'</td>';
		echo '<td>'.$this->title.'</td>';
		echo '<td>'.$this->author_ID.'</td>';
		echo '<td>'.$this->status.'</td>';
		echo '<td><a href="admin/posts/edit.php?id='.$this->ID.'">Edit</a></td>';
		echo '<tr>';
	}
}