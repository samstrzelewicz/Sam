<?php
require_once('template.php');
require_once('settings.php');
require_once('auth/Auth.php');
require_once('MySQLDB.php');
require_once('Post2.php');

Template::showHeader('Hotel Booking');
?>
<p>Hotel's Available:</p>
<?php

$pdo=MySQLDB::connect();

$posts=$pdo->query('SELECT * FROM posts');

while($post=$posts->fetch()){
	$p=new Post2($post);
	if(Auth::is_logged()) {
		$p->showLike();
	}
	$p->showPreview();
}
if('POST' == $_SERVER['REQUEST_METHOD']) {
	$query=$pdo->prepare("UPDATE posts set `likes` = `likes`+1 where `id` = '1' ");
	$query->execute();
}
Template::showFooter();