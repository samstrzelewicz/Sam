<?php
define('DB_SETTINGS',[
	'host'=>'localhost',
	'db'=>'hotel',
	'user'=>'root',
	'pass'=>''
]);
session_start();