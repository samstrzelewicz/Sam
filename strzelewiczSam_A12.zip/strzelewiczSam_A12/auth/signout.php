<?php
require('../settings.php');
require_once('Auth.php');
if(!Auth::is_logged()) header('location: ../index.php');
Auth::signout('location: signin.php');
header('location: ../index.php');