<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/User.php');
$user=new User();
$user->delete($_GET['id']);
header('location:index.php');