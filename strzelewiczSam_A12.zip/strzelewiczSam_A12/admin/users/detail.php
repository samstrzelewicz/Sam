<?php

require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/template.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/MySQLDB.php');

$pdo=MySQLDB::connect();
$query=$pdo->prepare('SELECT * FROM users WHERE ID=?');
$query->execute([$_GET['id']]);
if($query->rowCount()==0){
	Template::showHeader('User not found');
	echo 'There are no records matching your selection
	<a class="btn btn-outline-primary" href="index.php">Go back</a>';
}else{
	$user=$query->fetch();
	Template::showHeader($user['first_name'].' '.$user['last_name'].'\'s details');
	?>
	<a class="btn btn-outline-primary" href="admin/users/index.php">Go back</a>
	<a class="btn btn-warning" href="admin/users/edit.php?id=<?= $_GET['id'] ?>">Edit this user</a>
	<?php

		echo '<h3>'.$user['first_name'].' '.$user['last_name'].'</h3>';
		echo '<p class="lead">E-mail: '.$user['email'].'</p>';
	}
Template::showFooter();