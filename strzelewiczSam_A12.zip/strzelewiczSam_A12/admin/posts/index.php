<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/MySQLDB.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/template.php');

Template::showHeader('Manage posts');

?>
<a class="btn btn-primary" href="posts/create.php">Create new post</a>
<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/Post2.php');
$pdo=MySQLDB::connect();
$rows=$pdo->query('SELECT * FROM posts');
echo '<table class="table">';
$counter=0;
while($row=$rows->fetch()){
	$post=new Post2($row);
	$post->showTableRow();
}
echo '</table>';
Template::showFooter();