<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/admin/Admin.php');
Admin::isAdmin('../index.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/Post2.php');
$post=new Post2();
$post->delete($_GET['id']);
header('location:index.php');