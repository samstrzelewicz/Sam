<?php

class Admin{

	static function isAdmin($redirect_URL){
		require_once('/opt/lampp/htdocs/strzelewiczSam_A12/MySQLDB.php');
		$pdo=MySQLDB::connect();
		$query=$pdo->prepare('SELECT role FROM users WHERE ID=?');
		$query->execute([$_SESSION['user/ID']]);
		$user=$query->fetch();
		if($user['role']<1) header('location: '.$redirect_URL);
	}
}