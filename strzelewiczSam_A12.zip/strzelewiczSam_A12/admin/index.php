<?php
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/settings.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/auth/Auth.php');
if(!Auth::is_logged()) header('location: ../index.php');
require_once('/opt/lampp/htdocs/strzelewiczSam_A12/admin/Admin.php');
Admin::isAdmin('../index.php');

require_once('/opt/lampp/htdocs/strzelewiczSam_A12/template.php');

Template::showHeader('Welcome to the admin section');
?>
<p><a href="admin/users">Manage users</a></p>
<p><a href="admin/posts">Manage posts</a></p>
<?php

Template::showFooter();