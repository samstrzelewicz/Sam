-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 28, 2020 at 04:40 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `ID` int(10) UNSIGNED NOT NULL,
  `pic` varchar(200) DEFAULT NULL,
  `title` varchar(140) NOT NULL,
  `author_ID` int(10) UNSIGNED DEFAULT NULL,
  `content` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT 0,
  `date_published` datetime DEFAULT NULL,
  `likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`ID`, `pic`, `title`, `author_ID`, `content`, `date_created`, `status`, `date_published`, `likes`) VALUES
(1, 'https://www.omnihotels.com/-/media/images/hotels/pvddtn/digex/hero/pvddtn-2880x1870.jpg', 'Motel 7', 2, 1, NULL, 0, NULL, 94),
(2, 'http://ihg.scene7.com/is/image/ihg/holiday-inn-hotel-and-suites-oakland-2533422671-4x3', 'Red Roof INN', 0, 1, NULL, 0, NULL, 22),
(4, 'https://cache.marriott.com/marriottassets/marriott/HNLWI/hnlwi-cochere-1995-hor-wide.jpg?interpolation=progressive-bilinear&downsize=1440px:*', 'Hilton', 0, 1, NULL, -1, NULL, 0),
(5, NULL, 'Test Hotel', 0, 2, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(10) UNSIGNED NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `date_registered` datetime DEFAULT NULL,
  `date_deleted` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `email`, `password`, `role`, `first_name`, `last_name`, `status`, `date_registered`, `date_deleted`) VALUES
(1, 'sam@gmail.com', '', 0, 'Sam', 'Strzelewicz', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'bob@gmail.com', '$2y$10$Dhb0yin3.wXtVAJPuuTXnO/YrHCH8W8tzbd5OSO.x1c7kgzOa.UYi', 1, 'Bob', 'Bob', 0, '2020-04-19 11:03:51', NULL),
(3, 'test@gmail.com', '$2y$10$mWJczCwGN.L1oc91KT2KqOGd6qPIMETrnjeaJDMFIYycCJ04CoQAG', 1, 'Test', 'User', 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
